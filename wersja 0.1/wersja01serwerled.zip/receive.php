
<!DOCTYPE html>
<?php
	$led_state1=$_POST['ledstatus'];
	$data=array($led_state1,$led_state1,$led_state1);
	//$myObject->param1=$led_state1;
	//$myObject->param2=$led_state1;
	//$myObject->param3=$led_state1;
	$fp = fopen('control_data.json', 'w');
	fwrite($fp, json_encode($data));
	fclose($fp);
//	header('Location:index.php');
?>